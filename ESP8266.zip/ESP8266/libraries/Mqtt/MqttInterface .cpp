/*
 * MqttInterface.cpp
 *
 *  Created on:22/08/2020
 *      Author: marc
 */


#include "MqttInterface.h"

MqttInterface::MqttInterface(const char* machineName,const char* netName){
	this->machineName=machineName;
	this->netName=netName;
	
	
}
